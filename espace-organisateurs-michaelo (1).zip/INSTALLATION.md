# Espace organisateurs · Un Noël à Versailles

Logiciel du jour J protégé par un identifiant et un mot de passe communs, réservé au bureau et aux chefs de pôle.

## 1. Mettre la page en ligne (3 min)

Votre site est publié par Netlify depuis le dossier `site` du dépôt `Cr-chevivante`.

1. Sur github.com, ouvrez le dépôt **michaeloassociation-ctrl/Cr-chevivante**, puis le dossier **site**.
2. **Add file → Upload files** : glissez le dossier `espace-organisateurs` (il contient un seul fichier, `index.html`).
3. En bas : message « Espace organisateurs », « Commit directly to the main branch », puis **Commit changes**.
4. Netlify republie le site en 1 à 2 minutes. La page est alors à l'adresse :
   `https://www.asso-michaelo.com/espace-organisateurs/`

La page porte une balise « noindex » : Google ne la référence pas.

**Lien depuis le site (facultatif)** : dans `site/index.html`, crayon (Edit), cherchez
`<span><a href="mentions-legales.html">Mentions légales</a></span>` et remplacez par
`<span><a href="mentions-legales.html">Mentions légales</a> · <a href="espace-organisateurs/" rel="nofollow">Espace organisateurs</a></span>`
puis **Commit changes**.

## 2. Accès

- Identifiant et mot de passe : communiqués à part (voir le message de Claude).
- L'identifiant ne tient pas compte des majuscules ; le mot de passe, si.
- « Rester connecté » évite de retaper le mot de passe sur son téléphone.
- Pour changer les accès : dans le logiciel, **Outils → Données → Changer l'identifiant ou le mot de passe**. Une nouvelle page `index.html` est générée : remplacez l'ancienne sur GitHub. Tout le monde devra se reconnecter.

Le contenu (contacts, budget, planning) est chiffré (AES-256, clé dérivée du mot de passe) : sans les accès, le fichier présent sur GitHub est illisible, même pour quelqu'un qui consulte le dépôt.

## 3. Partager les données en direct entre tous les téléphones (recommandé, 15 min)

Sans cette étape, chaque appareil garde ses propres données (cases cochées, caisse, messages). Pour que tout le monde voie la même chose en temps réel, il faut un petit serveur gratuit, Supabase :

1. Créez un compte sur supabase.com, puis **New project** (région : Paris / eu-west-3).
2. **SQL Editor → New query** : collez le contenu de `supabase.sql`, puis **Run**.
3. **Authentication → Users → Add user → Create new user** :
   - Email : `orga@asso-michaelo.com` (ou une autre adresse de l'association) ;
   - Mot de passe : **exactement le même** que celui de l'espace organisateurs ;
   - cochez « Auto Confirm User ».
4. **Authentication → Sign In / Providers** : désactivez « Allow new users to sign up ».
5. **Project Settings → API** : copiez « Project URL » et la clé « anon public ».
6. Sur GitHub, ouvrez `espace-organisateurs/index.html`, cliquez sur le crayon (Edit), cherchez `MJ_CONFIG` près de la fin du fichier, et remplissez :
   ```
   "supabaseUrl": "https://xxxx.supabase.co",
   "supabaseAnonKey": "eyJ…",
   "email": "orga@asso-michaelo.com",
   ```
   puis **Commit changes**.

La clé « anon » peut être publique : sans le mot de passe commun, elle ne donne accès à rien.

Si vous changez un jour le mot de passe de l'espace organisateurs, changez aussi celui de l'utilisateur Supabase (Authentication → Users → … → Reset / Update password).

## 4. Bon à savoir

- La version sur claude.ai reste disponible ; ses données (partagées via claude.ai) sont séparées de celles du site.
- Avant le 12 décembre, faites un essai complet avec deux téléphones : cocher une tâche sur l'un doit l'afficher sur l'autre en quelques secondes.
- Gardez une sauvegarde : Outils → Données → Sauvegarde complète.
