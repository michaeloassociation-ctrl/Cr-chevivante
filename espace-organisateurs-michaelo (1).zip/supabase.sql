-- Synchronisation en direct du logiciel du jour J (Michaëlo)
-- À coller dans Supabase > SQL Editor > New query, puis « Run ».
create table if not exists public.michaelo_items (
  coll text not null,
  id text not null,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (coll, id)
);
alter table public.michaelo_items enable row level security;
-- Seuls les comptes connectés (l'identifiant commun) lisent et écrivent.
drop policy if exists "orga lecture" on public.michaelo_items;
drop policy if exists "orga ajout" on public.michaelo_items;
drop policy if exists "orga modif" on public.michaelo_items;
create policy "orga lecture" on public.michaelo_items for select to authenticated using (true);
create policy "orga ajout"   on public.michaelo_items for insert to authenticated with check (true);
create policy "orga modif"   on public.michaelo_items for update to authenticated using (true) with check (true);
alter publication supabase_realtime add table public.michaelo_items;
